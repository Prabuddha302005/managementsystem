from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse
from patient.models import Appointment
from patient.forms import AppointmentForm
from doctor.models import Doctor

def home(request):
    return render(request, 'patient/home.html')

def register(request):
    data = {}
    is_staff = False
    if request.method == "POST":
        uname = request.POST['username']
        name = request.POST['name']
        lastname = request.POST['lastname']
        email = request.POST['email']
        upass = request.POST['password']
        ucpass = request.POST['cpassword']
        user_type = request.POST['type']
        if user_type == 'doctor':
            is_staff = True
        if uname == "" or upass == "" or ucpass == "" or lastname=="" or name=="":
            data['error_msg'] = "Fields can't be empty"
            return render(request, 'patient/register.html', context=data)
        elif upass != ucpass:
            data['error_msg'] = "Passwords do not match"
            return render(request, 'patient/register.html', context=data)
        elif User.objects.filter(username=uname).exists():
            data['error_msg'] = f"{uname} already exists"
            return render(request, 'patient/register.html', context=data)
        else:
            user = User.objects.create(username=uname, is_staff=is_staff, first_name = name, last_name=lastname, email=email)
            user.set_password(upass)
            user.save()
            return redirect('/login')
    return render(request, 'patient/register.html', context=data)

def patient_login(request):
    data = {}
    if request.method == "POST":
        uname = request.POST['username']
        upass = request.POST['password']
        if uname == "" or upass == "":
            data['error_msg'] = "Fields can't be empty"
            return render(request, 'patient/login.html', context=data)
        elif not User.objects.filter(username=uname).exists():
            data['error_msg'] = f"{uname} does not exist"
            return render(request, 'patient/login.html', context=data)
        else:
            user = authenticate(username=uname, password=upass)
            if user is None:
                data['error_msg'] = "Wrong password"
                return render(request, 'patient/login.html', context=data)
            else:
                login(request, user)
                if user.is_staff:
                    return redirect("/dashboard")
                else:
                    return redirect('/')
    return render(request, 'patient/login.html')

def user_logout(request):
    logout(request)
    return redirect("/")

def show_doctors(request):
    data={}
    doctors = Doctor.objects.all()
    data['doctors'] =doctors
    return render(request, 'patient/book_appointment.html', context=data)




def book_appointment(request, id):
  
    get_doctor = Doctor.objects.get(id=id)

    if request.method == "POST":
        reasons = request.POST.get('reason')
        Appointment.objects.create(
            reason=reasons,
            doctor=get_doctor,
            patient=request.user,
            status='Scheduled'
        )
        return redirect("/my-appointments")

    return render(request, 'patient/appointments.html', {'doctor': get_doctor})

def view_appointment(request):
    appointment = Appointment.objects.filter(patient=request.user)
    return render(request, 'patient/view_appoinments.html', {'appointment': appointment})
