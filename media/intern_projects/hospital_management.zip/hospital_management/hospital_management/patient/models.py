from django.db import models
from django.contrib.auth.models import User
from doctor.models import Doctor
# Create your models here.


class Appointment(models.Model):
    patient = models.ForeignKey(User, related_name='appointments', on_delete=models.CASCADE)  # Link to Django User model
    doctor = models.ForeignKey(Doctor, related_name='appointments', on_delete=models.CASCADE)
    reason = models.CharField(max_length=50)
    status = models.CharField(max_length=20)
    choices=[
            ('Scheduled', 'Scheduled'),
            ('Completed', 'Completed'),
            ('Cancelled', 'Cancelled')
        ],
    default='Scheduled'
    

# Create your models here.
