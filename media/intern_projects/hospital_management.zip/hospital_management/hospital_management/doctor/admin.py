from django.contrib import admin
from doctor import models

# Register your models here.
admin.site.register(models.Doctor)
