from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Doctor(models.Model):
    uid = models.ForeignKey(User, on_delete=models.CASCADE, db_column="uid")
    name = models.CharField(max_length=50)
    speciality = models.CharField(max_length=100)
    qualifications = models.CharField(max_length=100)
    is_available = models.BooleanField(default=True)
    image = models.ImageField(upload_to='image')
    
