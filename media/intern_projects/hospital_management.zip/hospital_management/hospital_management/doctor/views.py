from django.shortcuts import render,redirect,get_object_or_404
from doctor.models import Doctor
from django.shortcuts import render, redirect, get_object_or_404
from doctor.forms import ImageForm
import os
from django.contrib.auth.models import User
from patient.models import Appointment
from django.http import HttpResponse

# Create your views here.
def booked_appointments(request):
    if request.user.is_authenticated:
        data = {}
        try:
            doctor = Doctor.objects.get(uid=request.user)
            get_appointments = Appointment.objects.filter(doctor=doctor)
            data['appointments'] = get_appointments
        except Doctor.DoesNotExist:
            data['appointments'] = []

        return render(request, 'doctor/dashboard.html', context=data)
    else:
        return redirect("/")
    
def add_doctor(request):
    # Check if the doctor already exists for the current user
    existing_doctor = Doctor.objects.filter(uid=request.user.id)
    print(f"Existing doctor records for user {request.user.id}: {existing_doctor}")

    if not existing_doctor:
        if request.method == 'POST':
            name = request.POST.get('name')
            speciality = request.POST.get('speciality')
            qualifications = request.POST.get('qualifications')
            is_available = 'is_available' in request.POST
            image = request.FILES.get('image')

            user_id = request.user
            created_Doctor = Doctor.objects.create(
                name=name,
                speciality=speciality,
                qualifications=qualifications,
                is_available=is_available,
                image=image,
                uid=user_id
            )
            created_Doctor.save()
            return redirect("/dashboard")
        else:
            return render(request, 'doctor/add_doctor.html')
    else:
        return HttpResponse("Doctor already exists")

def update_doctor(request, doctor_id):
    get_doctor = Doctor.objects.filter(id=doctor_id)

    
    if request.method == 'POST':
        name = request.POST.get('name')
        speciality = request.POST.get('speciality')
        qualifications = request.POST.get('qualifications')
        is_available = 'is_available' in request.POST
        image = request.FILES.get('image')
        get_doctor.update(name=name,speciality=speciality,qualifications=qualifications, is_available=is_available, image=image)

        return redirect('/dashboard')

    
    return render(request, 'doctor/update_doctor.html')


def delete_appointment(request, id):
     appointment = Appointment.objects.get(id=id)
     appointment.delete()
     return redirect("/dashboard")