from django import forms
from doctor.models import Doctor

class DoctorForm(forms.ModelForm):
    class Meta:
        model = Doctor
        fields = ['name', 'speciality', 'qualifications','is_available','image']


class ImageForm(forms.ModelForm):
    class Meta:
        model=Doctor
        fields=['image']
