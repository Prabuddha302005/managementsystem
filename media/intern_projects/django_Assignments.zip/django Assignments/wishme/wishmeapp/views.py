from django.shortcuts import render
from django.http import HttpResponse
import datetime
# Create your views here.


def wishMe(request):
    now = datetime.datetime.now()
    current_hour = now.hour
    print(current_hour)
    if 5 <= current_hour < 12:
        greeting = "Good morning"
    elif 12 <= current_hour < 18:
        greeting = "Good afternoon"
    elif 18 <= current_hour < 22:
        greeting = "Good evening"
    else:
        greeting = "Good night"

    response = f'<h1>{greeting} sir</h1><p>Current date and time: {now.strftime("%Y-%m-%d %H:%M:%S")}</p>'
    return HttpResponse(response)