from django.shortcuts import render

# Create your views here.
# demo_app/views.py
from django.shortcuts import render, redirect
from django.http import HttpResponse

def set_cookie(request):
    response = HttpResponse("Cookie has been set")
    response.set_cookie('user_name', 'Prabuddha', max_age=3600)  # Cookie expires in 1 hour
    return response

def get_cookie(request):
    user_name = request.COOKIES.get('user_name', 'Guest')
    return render(request, 'demo_app/show_cookie.html', {'user_name': user_name})

def set_session(request):
    request.session['user_id'] = 12345
    return HttpResponse("Session has been set")

def get_session(request):
    user_id = request.session.get('user_id', 'Not Logged In')
    return render(request, 'demo_app/show_session.html', {'user_id': user_id})
