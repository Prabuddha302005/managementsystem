from django.urls import path
from . import views

urlpatterns = [
    path('clients/', views.client_list, name='client_list'),
    path('clients/new/', views.register_client, name='register_client'),
    path('clients/<int:pk>/', views.client_detail, name='client_detail'),
    path('clients/<int:pk>/edit/', views.edit_client, name='edit_client'),
    path('clients/<int:pk>/delete/', views.delete_client, name='delete_client'),
    path('clients/<int:client_id>/projects/new/', views.add_project, name='add_project'),
    path('projects/', views.user_projects, name='user_projects'),
]