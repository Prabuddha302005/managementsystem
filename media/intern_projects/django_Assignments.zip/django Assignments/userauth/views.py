from django.shortcuts import render, get_object_or_404, redirect
from .models import Client, Project
from django.contrib.auth.decorators import login_required
from .forms import ClientForm, ProjectForm

@login_required
def register_client(request):
    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('client_list')
    else:
        form = ClientForm()
    return render(request, 'myapp/register_client.html', {'form': form})

@login_required
def client_list(request):
    clients = Client.objects.all()
    return render(request, 'myapp/client_list.html', {'clients': clients})

@login_required
def client_detail(request, pk):
    client = get_object_or_404(Client, pk=pk)
    return render(request, 'myapp/client_detail.html', {'client': client})

@login_required
def edit_client(request, pk):
    client = get_object_or_404(Client, pk=pk)
    if request.method == 'POST':
        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()
            return redirect('client_detail', pk=client.pk)
    else:
        form = ClientForm(instance=client)
    return render(request, 'myapp/edit_client.html', {'form': form})

@login_required
def delete_client(request, pk):
    client = get_object_or_404(Client, pk=pk)
    client.delete()
    return redirect('client_list')

@login_required
def add_project(request, client_id):
    client = get_object_or_404(Client, pk=client_id)
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            project = form.save(commit=False)
            project.client = client
            project.save()
            form.save_m2m()
            return redirect('client_detail', pk=client.pk)
    else:
        form = ProjectForm()
    return render(request, 'myapp/add_project.html', {'form': form, 'client': client})

@login_required
def user_projects(request):
    projects = request.user.projects.all()
    return render(request, 'myapp/user_projects.html', {'projects': projects})