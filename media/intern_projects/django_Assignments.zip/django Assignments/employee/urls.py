
from django.urls import path
from . import views

urlpatterns = [
    path('employee/<int:pk>/', views.employee_detail, name='employee_detail'),
    path('employee/new/', views.employee_create, name='employee_create'),
    # other URL patterns...
]
