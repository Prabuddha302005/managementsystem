def divide(a, b):
    # Check if the divisor is zero
    assert b != 0, "Divisor cannot be zero"
    return a / b

# Example usage
try:
    result = divide(10, 2)
    print("Division result:", result)
    
    result = divide(10, 0)
    print("Division result:", result)
except AssertionError as error:
    print(f"Assertion Error: {error}")
'''The assert keyword in Python is used for debugging purposes. It tests if a condition is true. If the condition is false, it raises an AssertionError with an optional message. This is useful for ensuring that the program runs as expected by catching potential issues early.'''
    